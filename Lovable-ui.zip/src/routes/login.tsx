import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import oliveBranch from "@/assets/olive-branch.png";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Giriş Yap — Olive Garden 2" },
      { name: "description", content: "Olive Garden 2 Yazlık Sitesi Yönetim Sistemi Girişi" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Login attempt:", { email, password });
  };

  return (
    <div className="relative flex min-h-screen w-full items-center justify-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('/__l5e/assets-v1/086ee4c4-a207-491a-8bce-931e9a5c90a4/hero.jpg')",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-olive-dark/80 via-olive/50 to-bark/60" />
      </div>

      {/* Organic decorative elements */}
      <svg
        className="absolute -top-20 -right-20 w-96 h-96 opacity-20 pointer-events-none"
        viewBox="0 0 400 400"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle cx="200" cy="200" r="180" stroke="currentColor" strokeWidth="0.5" />
        <circle cx="200" cy="200" r="140" stroke="currentColor" strokeWidth="0.5" />
        <circle cx="200" cy="200" r="100" stroke="currentColor" strokeWidth="0.5" />
        <path d="M200 20 L200 380 M20 200 L380 200" stroke="currentColor" strokeWidth="0.5" opacity="0.5" />
      </svg>

      {/* Floating olive leaves */}
      <svg
        className="absolute bottom-10 left-10 w-32 h-32 opacity-15 pointer-events-none text-cream"
        viewBox="0 0 100 100"
        fill="none"
      >
        <path d="M50 10 Q70 30 65 55 Q60 75 50 85 Q40 75 35 55 Q30 30 50 10Z" fill="currentColor" />
        <path d="M50 10 L50 85" stroke="currentColor" strokeWidth="1" opacity="0.5" />
        <ellipse cx="45" cy="40" rx="8" ry="3" fill="currentColor" opacity="0.4" transform="rotate(-20 45 40)" />
        <ellipse cx="55" cy="55" rx="8" ry="3" fill="currentColor" opacity="0.4" transform="rotate(20 55 55)" />
      </svg>

      <svg
        className="absolute top-20 right-10 w-24 h-24 opacity-10 pointer-events-none text-cream"
        viewBox="0 0 100 100"
        fill="none"
      >
        <path d="M50 10 Q70 30 65 55 Q60 75 50 85 Q40 75 35 55 Q30 30 50 10Z" fill="currentColor" />
        <path d="M50 10 L50 85" stroke="currentColor" strokeWidth="1" opacity="0.5" />
      </svg>

      {/* Content */}
      <div className="relative z-10 w-full max-w-md px-6">
        {/* Logo / Brand */}
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-cream/15 backdrop-blur-md border border-cream/30 shadow-lg shadow-olive-dark/20">
            <img
              src={oliveBranch}
              alt="Olive branch"
              className="w-14 h-14 object-contain opacity-90"
              loading="eager"
            />
          </div>
          <h1 className="text-3xl font-semibold tracking-tight text-cream drop-shadow-lg">
            Olive Garden 2
          </h1>
          <p className="mt-2 text-sm text-cream/70">
            Didim Akbük — Yazlık Sitesi Yönetim Sistemi
          </p>
        </div>

        {/* Login Card */}
        <div className="overflow-hidden rounded-3xl border border-cream/20 bg-cream/90 backdrop-blur-2xl shadow-2xl shadow-olive-dark/30">
          <div className="px-8 pt-8 pb-6">
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-olive">
                <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
                <polyline points="10 17 15 12 10 7" />
                <line x1="15" x2="3" y1="12" y2="12" />
              </svg>
              Giriş Yap
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Hesabınıza giriş yaparak site yönetimine erişin
            </p>
          </div>

          <form onSubmit={handleSubmit} className="px-8 pb-8 space-y-5">
            {/* Email */}
            <div className="space-y-2">
              <label
                htmlFor="email"
                className="text-sm font-medium text-foreground"
              >
                E-posta Adresi
              </label>
              <div className="relative">
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ornek@email.com"
                  className="w-full rounded-xl border border-input bg-background/60 px-4 py-3 pl-11 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none transition-all focus:border-olive focus:ring-2 focus:ring-olive/20"
                  required
                />
                <svg
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-olive/60"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect width="20" height="16" x="2" y="4" rx="2" />
                  <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                </svg>
              </div>
            </div>

            {/* Password */}
            <div className="space-y-2">
              <label
                htmlFor="password"
                className="text-sm font-medium text-foreground"
              >
                Şifre
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-xl border border-input bg-background/60 px-4 py-3 pl-11 pr-11 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none transition-all focus:border-olive focus:ring-2 focus:ring-olive/20"
                  required
                />
                <svg
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-olive/60"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground/60 hover:text-foreground transition-colors"
                >
                  {showPassword ? (
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                      <circle cx="12" cy="12" r="3" />
                      <path d="m4.2 4.2 15.6 15.6" />
                    </svg>
                  ) : (
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                      <circle cx="12" cy="12" r="3" />
                    </svg>
                  )}
                </button>
              </div>
            </div>

            {/* Remember & Forgot */}
            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  className="h-4 w-4 rounded border-border bg-background accent-olive"
                />
                <span className="text-muted-foreground">Beni hatırla</span>
              </label>
              <a
                href="#"
                className="text-olive hover:text-olive-dark font-medium transition-colors"
              >
                Şifremi unuttum
              </a>
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full rounded-xl bg-olive px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-olive/30 transition-all hover:bg-olive-dark hover:shadow-olive/40 active:scale-[0.98]"
            >
              Giriş Yap
            </button>

            {/* Divider */}
            <div className="relative py-2">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border/50" />
              </div>
              <div className="relative flex justify-center">
                <span className="bg-card px-3 text-xs text-muted-foreground">veya</span>
              </div>
            </div>

            {/* Register hint */}
            <p className="text-center text-sm text-muted-foreground">
              Hesabınız yok mu?{" "}
              <a href="#" className="font-medium text-olive hover:text-olive-dark transition-colors">
                Kayıt olun
              </a>
            </p>
          </form>
        </div>

        {/* Footer */}
        <div className="mt-6 flex items-center justify-center gap-2 text-center">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-cream/50">
            <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
            <circle cx="12" cy="10" r="3" />
          </svg>
          <p className="text-xs text-cream/50">
            Didim Akbük, Aydın — Olive Garden 2 Sitesi
          </p>
        </div>
      </div>
    </div>
  );
}
