import { createFileRoute, Link } from "@tanstack/react-router";
import oliveBranch from "@/assets/olive-branch.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Olive Garden 2 — Didim Akbük" },
      { name: "description", content: "Olive Garden 2 Yazlık Sitesi Yönetim Sistemi — Didim Akbük" },
      { property: "og:title", content: "Olive Garden 2 — Didim Akbük" },
      { property: "og:description", content: "Olive Garden 2 Yazlık Sitesi Yönetim Sistemi" },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <div className="relative flex min-h-screen w-full items-center justify-center overflow-hidden">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('/__l5e/assets-v1/086ee4c4-a207-491a-8bce-931e9a5c90a4/hero.jpg')",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-olive-dark/85 via-olive/50 to-bark/65" />
      </div>

      {/* Floating olive leaves decoration */}
      <svg
        className="absolute top-16 left-8 w-20 h-20 opacity-20 pointer-events-none text-cream"
        viewBox="0 0 100 100"
        fill="none"
      >
        <path d="M50 10 Q70 30 65 55 Q60 75 50 85 Q40 75 35 55 Q30 30 50 10Z" fill="currentColor" />
      </svg>
      <svg
        className="absolute bottom-24 right-12 w-16 h-16 opacity-15 pointer-events-none text-cream"
        viewBox="0 0 100 100"
        fill="none"
      >
        <path d="M50 10 Q70 30 65 55 Q60 75 50 85 Q40 75 35 55 Q30 30 50 10Z" fill="currentColor" />
      </svg>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-2xl">
        <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-cream/15 backdrop-blur-md border border-cream/30 shadow-lg shadow-olive-dark/20">
          <img
            src={oliveBranch}
            alt="Olive branch"
            className="w-16 h-16 object-contain opacity-90"
            loading="eager"
          />
        </div>
        <h1 className="text-5xl font-semibold tracking-tight text-cream drop-shadow-lg sm:text-6xl">
          Olive Garden 2
        </h1>
        <p className="mt-4 text-lg text-cream/70">
          Didim Akbük'teki huzur dolu yazlık sitenizin
          <br />
          dijital yönetim platformu
        </p>
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            to="/login"
            className="inline-flex items-center justify-center rounded-xl bg-cream/90 px-8 py-3.5 text-base font-semibold text-olive shadow-lg shadow-olive-dark/20 transition-all hover:bg-cream hover:shadow-olive-dark/30 active:scale-[0.98]"
          >
            Giriş Yap
          </Link>
          <a
            href="#"
            className="inline-flex items-center justify-center rounded-xl border border-cream/40 bg-cream/10 backdrop-blur-sm px-8 py-3.5 text-base font-medium text-cream transition-all hover:bg-cream/20 hover:border-cream/60"
          >
            Bilgi Al
          </a>
        </div>

        <div className="mt-12 flex items-center justify-center gap-2 text-cream/50">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="opacity-70">
            <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
            <circle cx="12" cy="10" r="3" />
          </svg>
          <p className="text-xs">
            Didim Akbük, Aydın — Olive Garden 2 Sitesi
          </p>
        </div>
      </div>
    </div>
  );
}
